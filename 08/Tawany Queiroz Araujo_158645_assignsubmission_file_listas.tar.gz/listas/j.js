let Salários = [
    '1º - Dudu (R$2.096.905)',
    '2º - Jorge (R$ 981.240)',
    '3º - Rony (R$530.979)',
    '4º - Gustavo Gómez (R$505.811)',
    '5º - Bruno Tabata (R$505.811)',
    '6º - Raphael Veiga (R$480.488)',
    '7º - Joaquín Piquerez (R$379.236)',
    '8º - Zé rafael (R$353.994)',
    '9º - Weverton (R$328.440)'
];

let elementoOl = document.getElementById('lista-palmeiras');

let posicao = 0;

for (const item of Salários) {
    posicao++;
    if(posicao % 2 == 1 ){
        elementoOl.innerHTML += `<li style="background: darkgreen">${item}</li>`;
    } else {
        elementoOl.innerHTML += `<li style="background: rgb(103, 199, 80)">${item}</li>`;
    }
    
}
